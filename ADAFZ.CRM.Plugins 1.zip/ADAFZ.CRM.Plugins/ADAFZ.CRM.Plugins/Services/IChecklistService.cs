﻿using System;

namespace ADAFZ.CRM.Plugins.Services
{
    public interface IChecklistService
    {
        void GenerateChecklist(Guid opportunityId);
        void ValidateMandatoryDocuments(Guid opportunityId);
        void GenerateStakeholderChecklist(Guid contactId);
    }
}