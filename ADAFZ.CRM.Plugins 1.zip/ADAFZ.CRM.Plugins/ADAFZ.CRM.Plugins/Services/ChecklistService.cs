﻿using ADAFZ.CRM.Plugins.Constants;
using ADAFZ.CRM.Plugins.Models;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ADAFZ.CRM.Plugins.Services
{
    public class ChecklistService : IChecklistService
    {
        private readonly IOrganizationService _service;
        private readonly ITracingService _tracing;

        public ChecklistService(
            IOrganizationService service,
            ITracingService tracing)
        {
            _service = service;
            _tracing = tracing;
        }

        public void GenerateChecklist(Guid opportunityId)
        {
            Entity opportunity =
                _service.Retrieve(
                    EntityNames.Opportunity,
                    opportunityId,
                    new ColumnSet(
                        OpportunityFields.LegalFramework, "ownerid"));

            EntityReference legalFramework =
                opportunity.GetAttributeValue<EntityReference>(
                    OpportunityFields.LegalFramework);
            EntityReference owner =
                opportunity.GetAttributeValue<EntityReference>(
                    "ownerid");

            DeActivateExistingChecklist(opportunityId);

            if (legalFramework == null)
            {
                return;
            }

            var mappings = GetMappings(
                            legalFramework.Id,
                            new List<int>
                            {
                                OptionSetValues.DocumentCategory.EntityDocuments
                            });

            foreach (var mapping in mappings)
            {
                CreateChecklistRecord(
                    opportunityId, owner,
                    mapping);
            }
        }

        private void DeActivateExistingChecklist(
            Guid opportunityId)
        {
            QueryExpression query =
                new QueryExpression(
                    EntityNames.OpportunityDocumentChecklist);

            query.ColumnSet =
                new ColumnSet(false);

            query.Criteria.AddCondition(
                "new_opportunity",
                ConditionOperator.Equal,
                opportunityId);

            EntityCollection records =
                _service.RetrieveMultiple(query);

            foreach (var record in records.Entities)
            {
                var request = new SetStateRequest
                {
                    EntityMoniker =
                        new EntityReference(
                            record.LogicalName,
                            record.Id),

                    State =
                        new OptionSetValue(1),

                    Status =
                        new OptionSetValue(2)
                };

                _service.Execute(request);
            }
        }

        private List<DocumentMappingModel> GetMappings(
            Guid legalFrameworkId,
            List<int> categories = null)
        {
            List<DocumentMappingModel> mappings =
                new List<DocumentMappingModel>();

            QueryExpression query =
                new QueryExpression(
                    EntityNames.LegalFrameworkDocumentMapping);

            query.ColumnSet = new ColumnSet(
                "new_documenttype",
                "new_documentcategory",
                "new_ismandatory",
                "new_allowedfileextensions");

            query.Criteria.AddCondition(
                "new_legalframework",
                ConditionOperator.Equal,
                legalFrameworkId);

            query.Criteria.AddCondition(
                "statecode",
                ConditionOperator.Equal,
                0);

            if (categories != null && categories.Any())
            {
                query.Criteria.AddCondition(
                    "new_documentcategory",
                    ConditionOperator.In,
                    categories.Cast<object>().ToArray());
            }

            query.AddOrder(
                "createdon",
                OrderType.Ascending);

            EntityCollection results =
                _service.RetrieveMultiple(query);

            foreach (Entity mapping in results.Entities)
            {
                EntityReference docType =
                    mapping.GetAttributeValue<EntityReference>(
                        "new_documenttype");

                if (docType == null)
                {
                    continue;
                }

                mappings.Add(
                    new DocumentMappingModel
                    {
                        DocumentType = docType,
                        DocumentName = docType.Name,
                        Category =
                            mapping.GetAttributeValue<OptionSetValue>(
                                "new_documentcategory"),
                        IsMandatory =
                            mapping.GetAttributeValue<bool>(
                                "new_ismandatory"),
                        AllowedFileExtensions =
                            mapping.GetAttributeValue<string>(
                                "new_allowedfileextensions")
                    });
            }

            return mappings;
        }

        private void CreateChecklistRecord(
            Guid opportunityId,
            EntityReference owner,
            DocumentMappingModel mapping,
            EntityReference contact = null)
        {
            Entity checklist =
                new Entity(
                    EntityNames.OpportunityDocumentChecklist);

            _tracing.Trace($"Creating Checklist Record : {mapping.DocumentName}");

            _tracing.Trace($"Category : {mapping.Category?.Value}");

            _tracing.Trace($"Mandatory : {mapping.IsMandatory}");

            checklist["new_name"] =
                mapping.DocumentName;

            checklist["new_opportunity"] =
                new EntityReference(
                    EntityNames.Opportunity,
                    opportunityId);

            if (contact != null)
            {
                checklist["new_contact"] =
                    contact;
            }

            checklist["new_documenttype"] =
                mapping.DocumentType;

            checklist["new_documentcategory"] =
                mapping.Category;

            checklist["new_ismandatory"] =
                mapping.IsMandatory;

            checklist["new_documentuploadstatus"] =
                new OptionSetValue(
                    OptionSetValues.UploadStatus.PendingUpload);

            checklist["new_allowedfileextensions"] =
                mapping.AllowedFileExtensions;

            checklist["ownerid"] =
                owner;

            _service.Create(checklist);
        }

        public void ValidateMandatoryDocuments(
            Guid opportunityId)
        {

            Entity opportunity =_service.Retrieve(EntityNames.Opportunity, opportunityId, new ColumnSet("new_documentstatus"));

            OptionSetValue documentStatus =opportunity.GetAttributeValue<OptionSetValue>("new_documentstatus");

            if (documentStatus == null)
            {
                return;
            }

            _tracing.Trace(
                $"Document Upload Status={documentStatus.Value}");

            if (documentStatus.Value == 1)
            {
                throw new InvalidPluginExecutionException(
                    "Please complete the Document review and change the Document uploaded status from Failed to Success before moving to the Payment Verification stage.");
            }


            QueryExpression query =
                new QueryExpression(
                    EntityNames.OpportunityDocumentChecklist);

            query.ColumnSet =
                new ColumnSet(
                    "new_name",
                    "new_ismandatory",
                    "new_documentuploadstatus");

            query.Criteria.AddCondition(
                "new_opportunity",
                ConditionOperator.Equal,
                opportunityId);

            query.Criteria.AddCondition(
                "new_ismandatory",
                ConditionOperator.Equal,
                true);

            query.Criteria.AddCondition(
                "statecode",
                ConditionOperator.Equal,
                0);

            EntityCollection records =
                _service.RetrieveMultiple(query);

            List<string> invalidDocuments =
                new List<string>();

            foreach (Entity document in records.Entities)
            {
                OptionSetValue status =
                    document.GetAttributeValue<OptionSetValue>(
                        "new_documentuploadstatus");

                if (status == null ||
                    status.Value != OptionSetValues.UploadStatus.Approved)
                {
                    invalidDocuments.Add(
                        document.GetAttributeValue<string>(
                            "new_name"));
                }
            }

            if (invalidDocuments.Count > 0)
            {
                //throw new InvalidPluginExecutionException(
                //    $"Cannot move to Payment Verification. " +
                //    $"{invalidDocuments.Count} mandatory document(s) are pending approval: " +
                //    $"{string.Join(", ", invalidDocuments)}.");
            }
        }

        public void GenerateStakeholderChecklist(Guid contactId)
        {
            _tracing.Trace("=================================================");
            _tracing.Trace("GenerateStakeholderChecklist - Started");
            _tracing.Trace($"Contact Id : {contactId}");

            Entity contact =
                _service.Retrieve(
                    EntityNames.Contact,
                    contactId,
                    new ColumnSet(
                        ContactFields.Opportunity,
                        ContactFields.CountryOfResidence,
                        ContactFields.ChooseRole,
                        ContactFields.ShareholderType));

            _tracing.Trace("Contact retrieved successfully.");

            DeActivateExistingStakeholderChecklist(contactId);

            _tracing.Trace(
                $"Has Opportunity : {contact.Contains(ContactFields.Opportunity)}");

            _tracing.Trace(
                $"Has Country Of Residence : {contact.Contains(ContactFields.CountryOfResidence)}");

            _tracing.Trace(
                $"Has Role : {contact.Contains(ContactFields.ChooseRole)}");

            _tracing.Trace(
                $"Has Shareholder Type : {contact.Contains(ContactFields.ShareholderType)}");

            EntityReference opportunity =
                contact.GetAttributeValue<EntityReference>(
                    ContactFields.Opportunity);

            if (opportunity == null)
            {
                _tracing.Trace(
                    "new_opportunity not found. Trying parentcontactid lookup.");

                QueryExpression opportunityQuery =
                    new QueryExpression(
                        EntityNames.Opportunity);

                opportunityQuery.ColumnSet =
                    new ColumnSet(
                        OpportunityFields.LegalFramework,
                        "ownerid");

                opportunityQuery.Criteria.AddCondition(
                    "parentcontactid",
                    ConditionOperator.Equal,
                    contactId);

                Entity opportunityFromContact =
                    _service.RetrieveMultiple(
                        opportunityQuery)
                    .Entities
                    .FirstOrDefault();

                if (opportunityFromContact == null)
                {
                    _tracing.Trace(
                        "No opportunity found using parentcontactid.");

                    return;
                }

                opportunity =
                    opportunityFromContact.ToEntityReference();

                _tracing.Trace(
                    $"Opportunity found using parentcontactid : {opportunity.Id}");

                try
                {
                    Entity updateContact =
                        new Entity(
                            EntityNames.Contact,
                            contactId);

                    updateContact[
                        ContactFields.Opportunity] =
                        opportunity;

                    _service.Update(updateContact);

                    _tracing.Trace(
                        "Successfully updated Contact.new_opportunity");
                }
                catch (Exception ex)
                {
                    _tracing.Trace(
                        $"Failed updating Contact.new_opportunity : {ex}");
                }
            }

            _tracing.Trace(
                $"Final Opportunity Id : {opportunity.Id}");

            Entity opportunityRecord =
                _service.Retrieve(
                    EntityNames.Opportunity,
                    opportunity.Id,
                    new ColumnSet(
                        OpportunityFields.LegalFramework,
                        "ownerid"));

            _tracing.Trace(
                "Opportunity retrieved successfully.");

            EntityReference legalFramework =
                opportunityRecord.GetAttributeValue<EntityReference>(
                    OpportunityFields.LegalFramework);

            EntityReference owner =
                opportunityRecord.GetAttributeValue<EntityReference>(
                    "ownerid");

            if (legalFramework == null)
            {
                _tracing.Trace(
                    "Legal Framework is NULL.");

                return;
            }

            _tracing.Trace(
                $"Legal Framework Id : {legalFramework.Id}");

            OptionSetValueCollection roles =
                contact.GetAttributeValue<OptionSetValueCollection>(
                    ContactFields.ChooseRole);

            if (roles == null)
            {
                _tracing.Trace(
                    "Roles are NULL.");
            }
            else
            {
                _tracing.Trace(
                    $"Roles : {string.Join(",", roles.Select(x => x.Value))}");
            }

            OptionSetValue shareholderType =
                contact.GetAttributeValue<OptionSetValue>(
                    ContactFields.ShareholderType);

            _tracing.Trace(
                $"Shareholder Type : {(shareholderType != null ? shareholderType.Value.ToString() : "NULL")}");

            bool isUaeResident =
                IsUaeResident(contact);

            _tracing.Trace(
                $"Is UAE Resident : {isUaeResident}");

            List<int> categories =
                GetStakeholderCategories(roles);

            _tracing.Trace(
                $"Categories : {string.Join(",", categories)}");

            List<DocumentMappingModel> mappings =
                GetMappings(
                    legalFramework.Id,
                    categories);

            _tracing.Trace(
                $"Mappings Count : {mappings.Count}");

            foreach (DocumentMappingModel mapping in mappings)
            {
                _tracing.Trace(
                    $"Evaluating Document : {mapping.DocumentName}");

                _tracing.Trace(
                    $"Category : {mapping.Category?.Value}");

                bool shouldCreate =
                    ShouldCreateDocument(
                        mapping,
                        isUaeResident,
                        roles,
                        shareholderType);

                _tracing.Trace(
                    $"Should Create : {shouldCreate}");

                if (!shouldCreate)
                {
                    _tracing.Trace(
                        $"Skipped : {mapping.DocumentName}");

                    continue;
                }

                _tracing.Trace(
                    $"Creating Checklist Record : {mapping.DocumentName}");

                CreateChecklistRecord(
                    opportunity.Id,
                    owner,
                    mapping,
                    contact.ToEntityReference());
            }

            _tracing.Trace(
                "GenerateStakeholderChecklist - Completed");
            _tracing.Trace(
                "=================================================");
        }

        private bool IsUaeResident(Entity contact)
        {
            _tracing.Trace(
                "----- IsUaeResident Started -----");

            EntityReference country =
                contact.GetAttributeValue<EntityReference>(
                    ContactFields.CountryOfResidence);

            if (country == null)
            {
                _tracing.Trace(
                    "Country Of Residence is NULL.");

                return false;
            }

            _tracing.Trace(
                $"Country Id : {country.Id}");

            _tracing.Trace(
                $"Country Name : {country.Name}");

            Entity countryRecord =
                _service.Retrieve(
                    country.LogicalName,
                    country.Id,
                    new ColumnSet(
                        "new_adracountrycode"));

            string countryCode =
                countryRecord.GetAttributeValue<string>(
                    "new_adracountrycode");

            _tracing.Trace(
                $"Country Code : [{countryCode}]");

            _tracing.Trace(
                $"Expected UAE Code : [{OptionSetValues.CountryCode.UAE}]");

            bool isUae =
                string.Equals(
                    countryCode?.Trim(),
                    OptionSetValues.CountryCode.UAE?.Trim(),
                    StringComparison.OrdinalIgnoreCase);

            _tracing.Trace(
                $"Is UAE Resident Result : {isUae}");

            return isUae;
        }

        private bool ShouldCreateDocument(
            DocumentMappingModel mapping,
            bool isUaeResident,
            OptionSetValueCollection roles,
            OptionSetValue shareholderType)
        {
            _tracing.Trace("-------------------------------------------------");
            _tracing.Trace(
                $"ShouldCreateDocument Started");

            _tracing.Trace(
                $"Document Name : {mapping.DocumentName}");

            _tracing.Trace(
                $"Category : {(mapping.Category != null ? mapping.Category.Value.ToString() : "NULL")}");

            _tracing.Trace(
                $"Is UAE Resident : {isUaeResident}");

            _tracing.Trace(
                $"Shareholder Type : {(shareholderType != null ? shareholderType.Value.ToString() : "NULL")}");

            if (roles == null)
            {
                _tracing.Trace("Roles : NULL");
            }
            else
            {
                _tracing.Trace(
                    $"Roles : {string.Join(",", roles.Select(x => x.Value))}");
            }

            if (mapping.DocumentName.Equals(
                "Emirates ID",
                StringComparison.OrdinalIgnoreCase))
            {
                _tracing.Trace(
                    $"Emirates ID Rule Matched. Returning {isUaeResident}");

                return isUaeResident;
            }

            if (mapping.DocumentName.Equals(
                "Visa Copy",
                StringComparison.OrdinalIgnoreCase))
            {
                _tracing.Trace(
                    $"Visa Copy Rule Matched. Returning {isUaeResident}");

                return isUaeResident;
            }

            if (mapping.Category != null
                && mapping.Category.Value ==
                   OptionSetValues.DocumentCategory.UBO
                && mapping.DocumentName.Equals(
                    "Passport Copy",
                    StringComparison.OrdinalIgnoreCase))
            {
                bool isUbo =
                    roles != null &&
                    roles.Any(x =>
                        x.Value ==
                        OptionSetValues.StakeholderRole.UBO);

                bool isIndividual =
                    shareholderType != null &&
                    shareholderType.Value ==
                        OptionSetValues.ShareholderType.Individual;

                _tracing.Trace(
                    $"UBO Passport Rule");

                _tracing.Trace(
                    $"Is UBO : {isUbo}");

                _tracing.Trace(
                    $"Is Individual : {isIndividual}");

                bool result =
                    isUbo && isIndividual;

                _tracing.Trace(
                    $"Final Result : {result}");

                return result;
            }

            _tracing.Trace(
                $"No special rule found for {mapping.DocumentName}. Returning TRUE.");

            return true;
        }

        private List<int> GetStakeholderCategories(
    OptionSetValueCollection roles)
        {
            List<int> categories =
                new List<int>();

            if (roles == null)
            {
                return categories;
            }

            if (roles.Any(x =>
                x.Value ==
                OptionSetValues.StakeholderRole.Shareholder))
            {
                categories.Add(
                    OptionSetValues.DocumentCategory.Shareholder);
            }

            if (roles.Any(x =>
                x.Value ==
                OptionSetValues.StakeholderRole.Director))
            {
                categories.Add(
                    OptionSetValues.DocumentCategory.Director);
            }

            if (roles.Any(x =>
                x.Value ==
                OptionSetValues.StakeholderRole.Manager))
            {
                categories.Add(
                    OptionSetValues.DocumentCategory.Manager);
            }

            if (roles.Any(x =>
                x.Value ==
                OptionSetValues.StakeholderRole.UBO))
            {
                categories.Add(
                    OptionSetValues.DocumentCategory.UBO);
            }

            return categories;
        }

        private void DeActivateExistingStakeholderChecklist(
    Guid contactId)
        {
            QueryExpression query =
                new QueryExpression(
                    EntityNames.OpportunityDocumentChecklist);

            query.ColumnSet =
                new ColumnSet(false);

            query.Criteria.AddCondition(
                "new_contact",
                ConditionOperator.Equal,
                contactId);

            query.Criteria.AddCondition(
                "statecode",
                ConditionOperator.Equal,
                0);

            EntityCollection records =
                _service.RetrieveMultiple(query);

            foreach (var record in records.Entities)
            {
                var request =
                    new SetStateRequest
                    {
                        EntityMoniker =
                            new EntityReference(
                                record.LogicalName,
                                record.Id),

                        State =
                            new OptionSetValue(1),

                        Status =
                            new OptionSetValue(2)
                    };

                _service.Execute(request);
            }
        }
    }
}