﻿using ADAFZ.CRM.Plugins.Services;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;

namespace ADAFZ.CRM.Plugins.Plugins
{
    public class OpportunityStageValidationForDocumentChecklistPlugin : IPlugin
    {
        private const string BpfEntityName =
            "new_businesstrackingpro";

        private const string DocumentVerificationStage =
            "Document Verification";

        private const string PaymentVerificationStage =
            "Payment Verification";

        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context =
                (IPluginExecutionContext)
                serviceProvider.GetService(
                    typeof(IPluginExecutionContext));

            if (context.Depth > 1)
            {
                return;
            }

            if (!context.InputParameters.Contains("Target"))
            {
                return;
            }

            Entity target =
                (Entity)context.InputParameters["Target"];

            if (target.LogicalName != BpfEntityName)
            {
                return;
            }

            if (!target.Contains("activestageid"))
            {
                return;
            }

            IOrganizationServiceFactory factory =
                (IOrganizationServiceFactory)
                serviceProvider.GetService(
                    typeof(IOrganizationServiceFactory));

            IOrganizationService service =
                factory.CreateOrganizationService(
                    context.UserId);

            ITracingService tracing =
                (ITracingService)
                serviceProvider.GetService(
                    typeof(ITracingService));

            try
            {
                tracing.Trace(
                    "OpportunityStageValidation Plugin Started");

                EntityReference newStage =
                    target.GetAttributeValue<EntityReference>(
                        "activestageid");

                EntityReference oldStage = null;

                if (context.PreEntityImages.Contains("PreImage"))
                {
                    oldStage =
                        context.PreEntityImages["PreImage"]
                        .GetAttributeValue<EntityReference>(
                            "activestageid");
                }

                if (oldStage == null || newStage == null)
                {
                    tracing.Trace(
                        "Old Stage or New Stage not found.");

                    return;
                }

                string oldStageName =
                    GetStageName(
                        service,
                        oldStage.Id);

                string newStageName =
                    GetStageName(
                        service,
                        newStage.Id);

                tracing.Trace(
                    $"Old Stage : {oldStageName}");

                tracing.Trace(
                    $"New Stage : {newStageName}");

                if (!(oldStageName == DocumentVerificationStage
                    && newStageName == PaymentVerificationStage))
                {
                    tracing.Trace(
                        "Validation skipped.");

                    return;
                }

                Entity bpf =
                    service.Retrieve(
                        BpfEntityName,
                        context.PrimaryEntityId,
                        new ColumnSet(
                            "bpf_opportunityid"));

                EntityReference opportunityRef =
                    bpf.GetAttributeValue<EntityReference>(
                        "bpf_opportunityid");

                if (opportunityRef == null)
                {
                    tracing.Trace(
                        "Opportunity lookup not found.");

                    return;
                }

                tracing.Trace(
                    $"Opportunity Id : {opportunityRef.Id}");

                IChecklistService checklistService =
                    new ChecklistService(
                        service,
                        tracing);

                checklistService.ValidateMandatoryDocuments(
                    opportunityRef.Id);

                tracing.Trace(
                    "Validation completed successfully.");
            }
            catch (Exception ex)
            {
                tracing.Trace(ex.ToString());
                throw;
            }
        }

        private string GetStageName(
            IOrganizationService service,
            Guid stageId)
        {
            Entity stage =
                service.Retrieve(
                    "processstage",
                    stageId,
                    new ColumnSet(
                        "stagename"));

            return stage.GetAttributeValue<string>(
                "stagename");
        }
    }
}