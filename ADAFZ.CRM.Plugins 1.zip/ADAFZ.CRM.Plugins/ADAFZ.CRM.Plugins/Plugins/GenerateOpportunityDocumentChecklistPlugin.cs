﻿using ADAFZ.CRM.Plugins.Services;
using Microsoft.Xrm.Sdk;
using System;

namespace ADAFZ.CRM.Plugins.Plugins
{
    public class GenerateOpportunityDocumentChecklistPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context =
                (IPluginExecutionContext)
                serviceProvider.GetService(
                    typeof(IPluginExecutionContext));



            if (context.Depth > 1)
            {
                return;
            }

            if (!context.InputParameters.Contains("Target"))
            {
                return;
            }

            Entity target =
                (Entity)context.InputParameters["Target"];

            if (target.LogicalName != "opportunity")
            {
                return;
            }

            IOrganizationServiceFactory factory =
                (IOrganizationServiceFactory)
                serviceProvider.GetService(
                    typeof(IOrganizationServiceFactory));

            IOrganizationService service =
                factory.CreateOrganizationService(
                    context.UserId);

            ITracingService tracing =
                (ITracingService)
                serviceProvider.GetService(
                    typeof(ITracingService));

            ChecklistService checklistService =
                new ChecklistService(
                    service,
                    tracing);

            tracing.Trace("Plugin started");
            tracing.Trace($"Message={context.MessageName}");
            tracing.Trace($"Entity={context.PrimaryEntityName}");

            checklistService.GenerateChecklist(
                target.Id);
        }
    }
}