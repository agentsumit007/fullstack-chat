﻿using ADAFZ.CRM.Plugins.Services;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace ADAFZ.CRM.Plugins.Plugins
{
    public class LeadQualificationGenerateDocumentChecklistPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context =
                (IPluginExecutionContext)
                serviceProvider.GetService(
                    typeof(IPluginExecutionContext));

            if (context.Depth > 1)
            {
                return;
            }

            if (!string.Equals(
                    context.MessageName,
                    "QualifyLead",
                    StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            IOrganizationServiceFactory factory =
                (IOrganizationServiceFactory)
                serviceProvider.GetService(
                    typeof(IOrganizationServiceFactory));

            IOrganizationService service =
                factory.CreateOrganizationService(
                    context.UserId);

            ITracingService tracing =
                (ITracingService)
                serviceProvider.GetService(
                    typeof(ITracingService));

            try
            {
                tracing.Trace("LeadQualificationPlugin Started");

                tracing.Trace("Message Name: " + context.MessageName);

                tracing.Trace("Primary Entity Name: " + context.PrimaryEntityName);

                tracing.Trace("Primary Entity Id: " + context.PrimaryEntityId);

                if (!context.InputParameters.Contains("LeadId"))
                {
                    tracing.Trace("LeadId not found in InputParameters.");
                    return;
                }

                EntityReference leadRef =
                    (EntityReference)context.InputParameters["LeadId"];

                Guid leadId = leadRef.Id;

                tracing.Trace($"Lead Id : {leadId}");

                QueryExpression opportunityQuery =
                    new QueryExpression("opportunity")
                    {
                        ColumnSet = new ColumnSet(
                            "opportunityid",
                            "new_legalframework")
                    };

                opportunityQuery.Criteria.AddCondition(
                    "originatingleadid",
                    ConditionOperator.Equal,
                    leadId);

                opportunityQuery.AddOrder(
                    "createdon",
                    OrderType.Descending);

                Entity opportunity =
                    service.RetrieveMultiple(
                        opportunityQuery)
                        .Entities
                        .FirstOrDefault();

                if (opportunity == null)
                {
                    tracing.Trace(
                        "No Opportunity found for Lead.");

                    return;
                }

                tracing.Trace(
                    $"Opportunity Found : {opportunity.Id}");

                ChecklistService checklistService =
                    new ChecklistService(
                        service,
                        tracing);

                checklistService.GenerateChecklist(
                    opportunity.Id);

                tracing.Trace(
                    "Checklist generation completed.");
            }
            catch (Exception ex)
            {
                tracing.Trace(
                    $"Exception : {ex}");

                throw;
            }
        }
    }
}