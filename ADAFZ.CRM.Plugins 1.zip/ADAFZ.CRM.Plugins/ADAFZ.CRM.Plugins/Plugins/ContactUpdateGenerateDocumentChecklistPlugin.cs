﻿using ADAFZ.CRM.Plugins.Services;
using Microsoft.Xrm.Sdk;
using System;

namespace ADAFZ.CRM.Plugins
{
    public class ContactUpdateGenerateDocumentChecklistPlugin : IPlugin
    {
        public void Execute(
            IServiceProvider serviceProvider)
        {
            ITracingService tracing =
                (ITracingService)
                serviceProvider.GetService(
                    typeof(ITracingService));

            try
            {
                IPluginExecutionContext context =
                    (IPluginExecutionContext)
                    serviceProvider.GetService(
                        typeof(IPluginExecutionContext));

                tracing.Trace("ContactUpdateGenerateDocumentChecklistPlugin Started");

                tracing.Trace("Message Name: " + context.MessageName);

                tracing.Trace("Primary Entity Name: " + context.PrimaryEntityName);

                tracing.Trace("Primary Entity Id: " + context.PrimaryEntityId);

                if (!context.InputParameters.Contains("Target"))
                {
                    return;
                }

                Entity target =
                    context.InputParameters["Target"]
                    as Entity;

                if (target == null)
                {
                    return;
                }

                IOrganizationServiceFactory serviceFactory =
                    (IOrganizationServiceFactory)
                    serviceProvider.GetService(
                        typeof(IOrganizationServiceFactory));

                IOrganizationService service =
                    serviceFactory.CreateOrganizationService(
                        context.UserId);

                IChecklistService checklistService =
                    new ChecklistService(
                        service,
                        tracing);

                checklistService.GenerateStakeholderChecklist(
                    target.Id);
            }
            catch (Exception ex)
            {
                tracing.Trace(
                    $"ContactUpdateGenerateDocumentChecklistPlugin Error : {ex}");

                throw;
            }
        }
    }
}