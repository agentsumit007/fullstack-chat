﻿namespace ADAFZ.CRM.Plugins.Constants
{
    public static class OptionSetValues
    {
        public static class UploadStatus
        {
            public const int PendingUpload = 100000000;
            public const int Uploaded = 100000001;
            public const int PendingReview = 100000002;
            public const int Approved = 100000003;
            public const int Rejected = 100000004;
        }
        public static class DocumentCategory
        {
            public const int EntityDocuments = 1;
            public const int Shareholder = 2;
            public const int Director = 3;
            public const int Manager = 4;
            public const int UBO = 5;
        }

        public static class StakeholderRole
        {
            public const int Shareholder = 102;
            public const int Director = 114;
            public const int Manager = 105;
            public const int UBO = 115;
        }

        public static class ShareholderType
        {
            public const int Individual = 101;
        }

        public static class CountryCode
        {
            public const string UAE = "211";
        }
    }
}