﻿namespace ADAFZ.CRM.Plugins.Constants
{
    public static class OpportunityFields
    {
        public const string LegalFramework = "new_legalframework";
    }
}