﻿namespace ADAFZ.CRM.Plugins.Constants
{
    public static class EntityNames
    {
        public const string Opportunity = "opportunity";

        public const string DocumentType = "new_documenttype";

        public const string LegalFrameworkDocumentMapping =
            "new_legalframeworkdocumentmapping";

        public const string OpportunityDocumentChecklist =
            "new_opportunitydocumentchecklist";
        public const string Contact = "contact";
        public const string Country = "new_country";
    }
}