﻿using Microsoft.Xrm.Sdk;

namespace ADAFZ.CRM.Plugins.Models
{
    public class DocumentMappingModel
    {
        public EntityReference DocumentType { get; set; }

        public string DocumentName { get; set; }

        public OptionSetValue Category { get; set; }

        public bool IsMandatory { get; set; }
        public string AllowedFileExtensions { get; set; }
    }
}