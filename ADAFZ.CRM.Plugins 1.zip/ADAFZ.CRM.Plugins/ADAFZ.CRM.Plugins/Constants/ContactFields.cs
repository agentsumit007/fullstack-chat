﻿namespace ADAFZ.CRM.Plugins.Constants
{
    public static class ContactFields
    {
        public const string Opportunity = "new_opportunity";

        public const string CountryOfResidence = "new_countryofresidence";

        public const string ChooseRole = "new_chooserole";

        public const string ShareholderType = "new_shareholdertype";
    }
}
